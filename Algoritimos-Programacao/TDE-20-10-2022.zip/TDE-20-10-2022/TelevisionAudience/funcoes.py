def args(arg):
    if arg == 4:
        return 'Rede Ulbra'
    elif arg == 5:
        return 'Rede Gremeio'
    elif arg == 7:
        return 'Bolso Tv'
    elif arg == 12:
        return 'Lula Flix'
