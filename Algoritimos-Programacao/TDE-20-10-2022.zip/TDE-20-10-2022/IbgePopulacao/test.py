dados = [1234,4321,7543,2314]
dados.sort(reverse=True)
dados.pop(0)
print(dados)