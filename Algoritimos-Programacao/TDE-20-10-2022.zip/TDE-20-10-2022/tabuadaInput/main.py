number = int(input("Digite um número: "))
print("\nTabuada do: ", number,'\n')
for i in range(1, 11):
    print(number, "x", i, "=", number * i)